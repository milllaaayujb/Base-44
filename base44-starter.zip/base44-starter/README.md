# Base44 Starter

A tiny HTML, CSS, and JavaScript project to ensure this GitHub repository contains code.

## Files
- `index.html` — page structure
- `style.css` — visual styling
- `script.js` — button interaction

This is only a starter repository. It does not automatically create or configure a Base44 app.
